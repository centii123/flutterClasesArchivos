import 'package:flutter/material.dart';

import 'page.dart';

void main() => runApp(MyApp());
